#include <stdio.h>
#include <stdlib.h>

int main (int argc, char **argv)
{
    if ( !printf("Hello world!\n") ) {
        perror("AIEEE!");
        exit -1;
    }
    return 0;
}
